#include <iostream> 
#include "card.cpp"


using namespace std;

int main(){
    cout << "uwu";
    
    
    
    
    
    
    
    return 0;
}